'use client'

import { useState } from 'react'
import { ArrowUpRight, Menu, X, Plus, ArrowDownRight } from 'lucide-react'

const projects = [
  { name: 'Project Placeholder 01', type: 'Local service business', note: 'Editable case study placeholder', tone: 'coral' },
  { name: 'Project Placeholder 02', type: 'Professional services', note: 'Editable case study placeholder', tone: 'blue' },
  { name: 'Project Placeholder 03', type: 'Hospitality & lifestyle', note: 'Editable case study placeholder', tone: 'lime' },
]

const services = [
  ['01', 'Custom business websites', 'A considered digital home for businesses ready to look established.'],
  ['02', 'Website redesign', 'Turn an outdated experience into something clearer, sharper and more useful.'],
  ['03', 'Conversion & UX', 'Structure information and journeys so the next step feels obvious.'],
  ['04', 'Mobile-first development', 'Responsive, accessible builds that work beautifully wherever people browse.'],
]

const faqs = [
  ['How does the process work?', 'We start with a focused conversation, then move through strategy, design, development, testing and launch.'],
  ['How long does a website take?', 'Timelines depend on scope and feedback. A clear project plan is shared before work begins.'],
  ['Can you redesign an existing website?', 'Yes. A redesign can clarify the story, improve mobile UX and make the experience feel current.'],
  ['Do you work with businesses outside India?', 'Yes. Collaboration can happen remotely with clear communication and shared project milestones.'],
  ['How many revisions are included?', 'Revision rounds are defined in the project scope so the process stays focused and intentional.'],
]

export default function Page() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [openFaq, setOpenFaq] = useState<number | null>(null)
  const [submitted, setSubmitted] = useState(false)

  return (
    <main className="site-shell">
      <nav className="nav-wrap" aria-label="Primary navigation">
        <a className="brand" href="#top" aria-label="Vanshaj Mishra home">VM<span>.</span></a>
        <div className="desktop-nav">
          {['Work', 'Services', 'Process', 'About', 'FAQ'].map((item) => <a key={item} href={`#${item.toLowerCase()}`}>{item}</a>)}
        </div>
        <a className="nav-cta" href="#contact">Start a project <ArrowUpRight data-icon="inline-end" /></a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'Close menu' : 'Open menu'}>{menuOpen ? <X /> : <Menu />}</button>
      </nav>
      {menuOpen && <div className="mobile-menu">{['Work', 'Services', 'Process', 'About', 'FAQ', 'Contact'].map((item) => <a key={item} href={`#${item.toLowerCase()}`} onClick={() => setMenuOpen(false)}>{item}<ArrowUpRight /></a>)}</div>}

      <section className="hero" id="top">
        <div className="eyebrow reveal">INDEPENDENT DIGITAL STUDIO · INDIA / WORLDWIDE</div>
        <h1 className="hero-title reveal delay-1">Websites that<br /><em>make businesses</em><br />look established<span className="dot">.</span></h1>
        <div className="hero-bottom reveal delay-2">
          <p>I design and build premium, conversion-focused websites for businesses that want a stronger digital presence and a better customer experience.</p>
          <div className="hero-actions"><a className="button button-primary" href="#contact">Start a project <ArrowUpRight /></a><a className="button button-link" href="#work">Explore my work <ArrowDownRight /></a></div>
        </div>
        <div className="hero-stage" aria-label="Abstract website interface preview"><div className="stage-label">DIGITAL PRESENCE / 01</div><div className="stage-word">better<span>↗</span></div><div className="stage-window"><div className="window-bar"><span></span><span></span><span></span><b>vanshaj.studio</b></div><div className="window-grid"><div><small>01 / 03</small><strong>Make a<br />stronger<br /><i>first impression.</i></strong></div><div className="window-shape"></div></div></div></div>
      </section>

      <section className="ticker" aria-label="Studio capabilities"><div>STRATEGY <span>✦</span> DESIGN <span>✦</span> DEVELOPMENT <span>✦</span> CLARITY <span>✦</span> STRATEGY <span>✦</span> DESIGN <span>✦</span></div></section>

      <section className="section work-section" id="work"><div className="section-head"><div className="eyebrow">SELECTED WORK / 01</div><h2>Thoughtful work for<br /><em>ambitious businesses.</em></h2><p>These are editable project placeholders, ready to be replaced with your real work and stories.</p></div><div className="project-grid">{projects.map((project, i) => <article className={`project-card ${project.tone}`} key={project.name}><div className="project-art"><span>CONCEPT / 0{i + 1}</span><div className="art-lines"></div><b>{i === 0 ? 'LOCAL' : i === 1 ? 'FORM / FUNCTION' : 'MAKE SPACE'}</b></div><div className="project-meta"><div><h3>{project.name}</h3><p>{project.type} · {project.note}</p></div><ArrowUpRight /></div></article>)}</div></section>

      <section className="section services-section" id="services"><div className="split-heading"><div className="eyebrow">WHAT I DO / 02</div><h2>A website should do<br />more than <em>exist.</em></h2></div><div className="service-list">{services.map(([num, title, text]) => <div className="service-row" key={num}><span>{num}</span><div><h3>{title}</h3><p>{text}</p></div><ArrowUpRight /></div>)}</div></section>

      <section className="statement"><div className="eyebrow">THE POINT OF GOOD DESIGN</div><h2>Less friction.<br /><span>More confidence.</span></h2><p>When your website makes the right things clear, people can understand your value and take the next step without second-guessing.</p></section>

      <section className="section process-section" id="process"><div className="eyebrow">A CLEARER WAY OF WORKING / 03</div><div className="process-intro"><h2>From first thought<br />to <em>final detail.</em></h2><p>No black boxes. No unnecessary layers. Just a focused process built around your business, your customers and the work that matters.</p></div><div className="process-grid">{['Discovery', 'Strategy', 'Design', 'Development', 'Launch'].map((step, i) => <div className="process-step" key={step}><span>0{i + 1}</span><h3>{step}</h3><p>{['Understand the business behind the brief.', 'Find the clearest story and structure.', 'Give the direction a distinctive form.', 'Build a responsive, considered experience.', 'Test, refine and put it in the world.'][i]}</p></div>)}</div></section>

      <section className="about-section" id="about"><div className="about-card"><div className="eyebrow">A LITTLE ABOUT ME / 04</div><h2>For businesses that have <em>outgrown</em> a basic online presence.</h2><p>I work with businesses to understand what they do, design a stronger digital presentation and build a website that makes the customer journey clearer.</p><a className="button button-light" href="#contact">Get to know me <ArrowUpRight /></a></div><div className="portrait-placeholder"><span>V</span><small>VANSHaj<br />MISHRA</small></div></section>

      <section className="section faq-section" id="faq"><div className="faq-title"><div className="eyebrow">GOOD QUESTIONS / 05</div><h2>Before we<br /><em>begin.</em></h2></div><div className="faq-list">{faqs.map(([q, a], i) => <div className="faq-item" key={q}><button onClick={() => setOpenFaq(openFaq === i ? null : i)}><span>0{i + 1}</span><b>{q}</b><Plus className={openFaq === i ? 'rotated' : ''} /></button>{openFaq === i && <p>{a}</p>}</div>)}</div></section>

      <section className="contact-section" id="contact"><div className="eyebrow">HAVE A PROJECT IN MIND? / 06</div><h2>Let's build<br /><em>something better.</em></h2><div className="contact-layout"><div><p>Tell me a little about what you are building, changing or figuring out. I will get back to you with a considered next step.</p><div className="direct-links"><a href="mailto:mishravanshaj021@gmail.com">mishravanshaj021@gmail.com <ArrowUpRight /></a><a href="https://wa.me/916398170767">WhatsApp <ArrowUpRight /></a><a href="https://instagram.com/mishra_vanshaj">@mishra_vanshaj <ArrowUpRight /></a></div></div><form onSubmit={(e) => { e.preventDefault(); setSubmitted(true) }}><label>Name<input required name="name" placeholder="Your name" /></label><label>Business / email<input required name="email" type="email" placeholder="How can I reach you?" /></label><label>Tell me about the project<textarea required name="message" placeholder="A few words are enough to start..." rows={4} /></label><button className="button button-primary" type="submit">{submitted ? 'Inquiry noted' : 'Send project inquiry'} <ArrowUpRight /></button>{submitted && <p className="form-note">Thanks — this demo form is ready to connect to your preferred email service for deployment.</p>}</form></div></section>

      <footer><div className="brand">VM<span>.</span></div><p>Premium websites for businesses ready to look the part.</p><div><a href="#top">Back to top ↑</a><span>© 2026 Vanshaj Mishra</span></div></footer>
    </main>
  )
}
